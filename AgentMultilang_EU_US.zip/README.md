
# Agent Multilang EU + US

1. Copia `.env.template` in `.env.json` e riempi:
   * `ADSENSE_ID`
   * `FORM_URLS` (7 embed URL)
   * `CPAGRIP_KEYS`

2. Carica tutto su un repository GitHub pubblico.

3. Abilita GitHub Pages (branch gh-pages).

4. Esegui:
```
pip install requests
python launch_agent.py
```
